#ifndef _SYS_H
#define _SYS_H

#include "stm32f0xx.h"

#define u8 unsigned char
#define u16 unsigned int
#define u32 unsigned long







#endif





