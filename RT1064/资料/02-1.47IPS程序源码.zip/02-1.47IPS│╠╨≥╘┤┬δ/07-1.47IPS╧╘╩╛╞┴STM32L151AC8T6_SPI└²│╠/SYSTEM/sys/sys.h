#ifndef _SYS_H
#define _SYS_H

#include "stm32l1xx_hal.h"

#define u8 unsigned char
#define u16 unsigned int
#define u32 unsigned long


void SystemClock_Config(void);




#endif





