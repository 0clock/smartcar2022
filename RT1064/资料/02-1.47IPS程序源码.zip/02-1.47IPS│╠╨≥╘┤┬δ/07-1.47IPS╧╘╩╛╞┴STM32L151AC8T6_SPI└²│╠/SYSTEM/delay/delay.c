#include "delay.h"


void delay_ms(uint32_t ms)
{
	HAL_Delay(ms);
}



