#include "Cpu.h"
#include "Events.h"


word speed = 0;


#pragma CODE_SEG DEFAULT


void TI1_OnInterrupt(void)
{
    speed =  Puls1_GetCounterValue();
    Puls1_ResetCounter();


}


