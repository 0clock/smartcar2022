#include "fun.h"

void my_delay(word t)
{
  while(t--);
}
int limit(int x, int y)
{
    if(x>y) return y;
    if(x<-y)return -y;
    return x;   
}